import logging
import sqlite3
import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes, MessageHandler, filters
from datetime import datetime

BOT_TOKEN = os.environ.get("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")

# Rewards
CORRECT_PREDICTION_REWARD = 50
REFERRAL_REWARD = 30
MIN_WITHDRAWAL = 500  # coins = $5

logging.basicConfig(level=logging.INFO)

# Sample matches (Admin can add more)
SAMPLE_MATCHES = [
    {"id": 1, "sport": "⚽ Football", "match": "Man United vs Arsenal", "date": "Today 8:00 PM", "options": ["Man United", "Arsenal", "Draw"]},
    {"id": 2, "sport": "⚽ Football", "match": "Barcelona vs Real Madrid", "date": "Tomorrow 9:00 PM", "options": ["Barcelona", "Real Madrid", "Draw"]},
    {"id": 3, "sport": "🏀 Basketball", "match": "Lakers vs Warriors", "date": "Today 10:00 PM", "options": ["Lakers", "Warriors"]},
    {"id": 4, "sport": "🏀 Basketball", "match": "Bulls vs Celtics", "date": "Tomorrow 7:00 PM", "options": ["Bulls", "Celtics"]},
    {"id": 5, "sport": "🎾 Tennis", "match": "Djokovic vs Nadal", "date": "Today 3:00 PM", "options": ["Djokovic", "Nadal"]},
    {"id": 6, "sport": "🥊 Boxing", "match": "Fury vs Joshua", "date": "Saturday 11:00 PM", "options": ["Fury", "Joshua"]},
]

def init_db():
    conn = sqlite3.connect("sportsbot.db")
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        coins INTEGER DEFAULT 0,
        referral_code TEXT,
        referred_by INTEGER,
        total_predictions INTEGER DEFAULT 0,
        correct_predictions INTEGER DEFAULT 0,
        btc_address TEXT
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS predictions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        match_id INTEGER,
        prediction TEXT,
        result TEXT DEFAULT 'pending',
        coins_earned INTEGER DEFAULT 0,
        created_at TEXT
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS matches (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sport TEXT,
        match TEXT,
        date TEXT,
        options TEXT,
        result TEXT DEFAULT 'pending',
        created_at TEXT
    )""")
    conn.commit()
    conn.close()

def get_user(user_id):
    conn = sqlite3.connect("sportsbot.db")
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
    user = c.fetchone()
    conn.close()
    return user

def add_user(user_id, username, referred_by=None):
    conn = sqlite3.connect("sportsbot.db")
    c = conn.cursor()
    ref_code = f"REF{user_id}"
    c.execute("INSERT OR IGNORE INTO users (user_id, username, referral_code, referred_by) VALUES (?,?,?,?)",
              (user_id, username, ref_code, referred_by))
    if referred_by:
        c.execute("UPDATE users SET coins=coins+? WHERE user_id=?", (REFERRAL_REWARD, referred_by))
    conn.commit()
    conn.close()

def get_coins(user_id):
    conn = sqlite3.connect("sportsbot.db")
    c = conn.cursor()
    c.execute("SELECT coins FROM users WHERE user_id=?", (user_id,))
    result = c.fetchone()
    conn.close()
    return result[0] if result else 0

def get_stats(user_id):
    conn = sqlite3.connect("sportsbot.db")
    c = conn.cursor()
    c.execute("SELECT total_predictions, correct_predictions FROM users WHERE user_id=?", (user_id,))
    result = c.fetchone()
    conn.close()
    return result if result else (0, 0)

def get_ref_code(user_id):
    conn = sqlite3.connect("sportsbot.db")
    c = conn.cursor()
    c.execute("SELECT referral_code FROM users WHERE user_id=?", (user_id,))
    result = c.fetchone()
    conn.close()
    return result[0] if result else f"REF{user_id}"

def save_prediction(user_id, match_id, prediction):
    conn = sqlite3.connect("sportsbot.db")
    c = conn.cursor()
    # Check if already predicted
    c.execute("SELECT id FROM predictions WHERE user_id=? AND match_id=?", (user_id, match_id))
    existing = c.fetchone()
    if existing:
        conn.close()
        return False
    c.execute("INSERT INTO predictions (user_id, match_id, prediction, created_at) VALUES (?,?,?,?)",
              (user_id, match_id, prediction, datetime.now().strftime("%Y-%m-%d %H:%M")))
    c.execute("UPDATE users SET total_predictions=total_predictions+1 WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()
    return True

def get_user_predictions(user_id):
    conn = sqlite3.connect("sportsbot.db")
    c = conn.cursor()
    c.execute("SELECT match_id, prediction, result, coins_earned FROM predictions WHERE user_id=? ORDER BY id DESC LIMIT 10", (user_id,))
    preds = c.fetchall()
    conn.close()
    return preds

def main_menu():
    keyboard = [
        [InlineKeyboardButton("🏆 Predict & Earn", callback_data="predict")],
        [InlineKeyboardButton("📊 My Predictions", callback_data="my_predictions")],
        [InlineKeyboardButton("💰 My Balance", callback_data="balance")],
        [InlineKeyboardButton("👥 Referral System", callback_data="referral")],
        [InlineKeyboardButton("🏅 Leaderboard", callback_data="leaderboard")],
        [InlineKeyboardButton("🏆 Withdraw BTC", callback_data="withdraw")],
    ]
    return InlineKeyboardMarkup(keyboard)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    args = context.args
    referred_by = None
    if args and args[0].startswith("REF"):
        try:
            referred_by = int(args[0][3:])
            if referred_by == user.id:
                referred_by = None
        except:
            referred_by = None

    if not get_user(user.id):
        add_user(user.id, user.username or user.first_name, referred_by)
        if referred_by:
            try:
                await context.bot.send_message(referred_by,
                    f"🎉 Someone joined using your referral!\n+{REFERRAL_REWARD} coins added!")
            except:
                pass

    await update.message.reply_text(
        f"🏆 *Welcome to SportsPredictBot!*\n\n"
        f"Predict sports results and earn coins!\n\n"
        f"⚽ Football • 🏀 Basketball • 🎾 Tennis • 🥊 Boxing\n\n"
        f"✅ Correct prediction → +{CORRECT_PREDICTION_REWARD} coins\n"
        f"👥 Referral bonus → +{REFERRAL_REWARD} coins\n\n"
        f"💸 Withdraw via *Bitcoin (BTC)*\n"
        f"Minimum: {MIN_WITHDRAWAL} coins ($5)\n\n"
        f"Let's predict and earn! 👇",
        parse_mode="Markdown",
        reply_markup=main_menu()
    )

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data = query.data

    if not get_user(user_id):
        add_user(user_id, query.from_user.username or query.from_user.first_name)

    if data == "menu":
        await query.edit_message_text(
            "🏆 *SportsPredictBot*\n\nChoose an option:",
            parse_mode="Markdown",
            reply_markup=main_menu()
        )

    elif data == "predict":
        keyboard = []
        for match in SAMPLE_MATCHES:
            keyboard.append([InlineKeyboardButton(
                f"{match['sport']} {match['match']}",
                callback_data=f"match_{match['id']}"
            )])
        keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="menu")])
        await query.edit_message_text(
            "🏆 *Available Matches*\n\nChoose a match to predict:",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    elif data.startswith("match_"):
        match_id = int(data.split("_")[1])
        match = next((m for m in SAMPLE_MATCHES if m["id"] == match_id), None)
        if not match:
            await query.edit_message_text("❌ Match not found!", reply_markup=main_menu())
            return
        context.user_data["current_match"] = match
        keyboard = []
        for option in match["options"]:
            keyboard.append([InlineKeyboardButton(option, callback_data=f"pred_{match_id}_{option}")])
        keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="predict")])
        await query.edit_message_text(
            f"🏆 *{match['match']}*\n"
            f"🏅 Sport: {match['sport']}\n"
            f"📅 Date: {match['date']}\n\n"
            f"Who will win? Choose your prediction:\n\n"
            f"✅ Correct prediction = +{CORRECT_PREDICTION_REWARD} coins!",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    elif data.startswith("pred_"):
        parts = data.split("_", 2)
        match_id = int(parts[1])
        prediction = parts[2]
        match = next((m for m in SAMPLE_MATCHES if m["id"] == match_id), None)

        success = save_prediction(user_id, match_id, prediction)
        kb = [
            [InlineKeyboardButton("🏆 Predict Another", callback_data="predict")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="menu")]
        ]

        if success:
            await query.edit_message_text(
                f"✅ *Prediction Saved!*\n\n"
                f"Match: *{match['match']}*\n"
                f"Your Pick: *{prediction}*\n\n"
                f"🎯 If correct you earn +{CORRECT_PREDICTION_REWARD} coins!\n"
                f"Results will be updated after the match.",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup(kb)
            )
        else:
            await query.edit_message_text(
                f"⚠️ *Already Predicted!*\n\n"
                f"You already predicted this match!\n"
                f"Try a different match.",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup(kb)
            )

    elif data == "my_predictions":
        preds = get_user_predictions(user_id)
        if not preds:
            kb = [[InlineKeyboardButton("🏆 Make Prediction", callback_data="predict")],
                  [InlineKeyboardButton("🔙 Back", callback_data="menu")]]
            await query.edit_message_text(
                "📊 *My Predictions*\n\nYou haven't made any predictions yet!\nStart predicting to earn coins!",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup(kb)
            )
            return

        text = "📊 *My Recent Predictions*\n\n"
        for pred in preds:
            match = next((m for m in SAMPLE_MATCHES if m["id"] == pred[0]), None)
            match_name = match["match"] if match else f"Match #{pred[0]}"
            status = "⏳ Pending" if pred[2] == "pending" else ("✅ Won" if pred[2] == "won" else "❌ Lost")
            coins = f"+{pred[3]} coins" if pred[3] > 0 else ""
            text += f"🏆 {match_name}\n"
            text += f"Pick: *{pred[1]}* | {status} {coins}\n\n"

        kb = [[InlineKeyboardButton("🔙 Back", callback_data="menu")]]
        await query.edit_message_text(text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(kb))

    elif data == "balance":
        coins = get_coins(user_id)
        total, correct = get_stats(user_id)
        usd = round(coins / 100, 2)
        win_rate = round((correct / total * 100), 1) if total > 0 else 0
        kb = [[InlineKeyboardButton("🔙 Back", callback_data="menu")]]
        await query.edit_message_text(
            f"💰 *My Stats*\n\n"
            f"🪙 Coins: *{coins}*\n"
            f"💵 Value: *${usd}*\n\n"
            f"📊 Total Predictions: *{total}*\n"
            f"✅ Correct: *{correct}*\n"
            f"🎯 Win Rate: *{win_rate}%*\n\n"
            f"{'✅ Ready to withdraw!' if coins >= MIN_WITHDRAWAL else f'Need {MIN_WITHDRAWAL - coins} more coins to withdraw'}",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(kb)
        )

    elif data == "referral":
        ref_code = get_ref_code(user_id)
        bot_username = (await context.bot.get_me()).username
        ref_link = f"https://t.me/{bot_username}?start={ref_code}"
        kb = [[InlineKeyboardButton("🔙 Back", callback_data="menu")]]
        await query.edit_message_text(
            f"👥 *Referral System*\n\n"
            f"Invite friends and earn *+{REFERRAL_REWARD} coins* per referral!\n\n"
            f"🔗 Your referral link:\n`{ref_link}`\n\n"
            f"Share this link with friends!\n"
            f"When they join you both benefit! 🎉",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(kb)
        )

    elif data == "leaderboard":
        conn = sqlite3.connect("sportsbot.db")
        c = conn.cursor()
        c.execute("SELECT username, coins, correct_predictions FROM users ORDER BY coins DESC LIMIT 10")
        top_users = c.fetchall()
        conn.close()

        text = "🏅 *Leaderboard - Top 10*\n\n"
        medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
        for i, user in enumerate(top_users):
            text += f"{medals[i]} *{user[0] or 'Anonymous'}* - {user[1]} coins ({user[2]} wins)\n"

        if not top_users:
            text += "No users yet! Be the first to predict! 🎯"

        kb = [[InlineKeyboardButton("🔙 Back", callback_data="menu")]]
        await query.edit_message_text(text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(kb))

    elif data == "withdraw":
        coins = get_coins(user_id)
        if coins < MIN_WITHDRAWAL:
            kb = [[InlineKeyboardButton("🔙 Back", callback_data="menu")]]
            await query.edit_message_text(
                f"❌ *Insufficient Balance*\n\n"
                f"You have: *{coins} coins*\n"
                f"Minimum: *{MIN_WITHDRAWAL} coins ($5)*\n\n"
                f"Keep predicting to earn more! 🎯",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup(kb)
            )
        else:
            context.user_data["withdrawing"] = True
            kb = [[InlineKeyboardButton("❌ Cancel", callback_data="menu")]]
            await query.edit_message_text(
                f"🏆 *Withdraw Bitcoin*\n\n"
                f"Your balance: *{coins} coins (${round(coins/100, 2)})*\n\n"
                f"Please send your *Bitcoin (BTC) wallet address*:",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup(kb)
            )

async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.user_data.get("withdrawing"):
        context.user_data["withdrawing"] = False
        user_id = update.effective_user.id
        coins = get_coins(user_id)
        usd = round(coins / 100, 2)
        await update.message.reply_text(
            f"✅ *Withdrawal Request Submitted!*\n\n"
            f"Amount: *{coins} coins (${usd})*\n"
            f"BTC Address: `{update.message.text}`\n\n"
            f"Your request will be processed within 24-48 hours.",
            parse_mode="Markdown",
            reply_markup=main_menu()
        )

def main():
    init_db()
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))
    print("✅ SportsPredictBot is running!")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
